======================================================================
                               RE:Sin
                A Sin beginning for S.T.A.L.K.E.R. GAMMA
                              Version 1.0.25
======================================================================

Called to the Generators. Entrusted with a gift. Sent among your brothers.

RE:Sin gives a Sin playthrough an introduction built around Chernobog,
Stribog, Dazhbog and the Cicatrix: an artifact that shields its bearer
from bullets, but must recover away from the artifact belt.

Designed for GAMMA with Re:Done's northern areas and Hospital NPCs.


THE CICATRIX
----------------------------------------------------------------------
* Receive the Cicatrix once through Chernobog's dialogue in Generators.
  The grant is available only to a Sin character.
* Absorbs 70% of incoming bullet damage while equipped and charged.
* Each protected hit drains the shield. Its charge drain has been raised
  from the original ZTC balance to offset the stronger protection.
* Recharges in your inventory while unequipped. It does not recharge
  while worn on the artifact belt.
* Gameplay difficulty scales drain and recharge, while protection stays 70%:
    Easy:    x1.00 drain / 5 minutes empty-to-full.
    Medium:  x1.25 drain / 7 minutes empty-to-full.
    Hard:    x1.50 drain / 9 minutes empty-to-full.
    Fourth difficulty, if enabled: x1.75 drain / 11 minutes.
  Drain multipliers are relative to version 1.0.23. Recharge uses active
  elapsed seconds, not accelerated world-clock hours. Economy/progression
  difficulty does not affect it. Partially drained and collapsed shields
  recharge at the same rate. Difficulty changes preserve existing charge.
* A fully collapsed field must recover completely before protecting you
  again. The artifact is initially given without charge.
* Includes ZTC's shield particles and shield-break sounds, charge state,
  belt persistence and a guard for the Press Key to Drop Item interaction.


A CALL TO SERVICE
----------------------------------------------------------------------
* The Beckoning: Chernobog calls a Sin character to the laboratory beneath
  the Generators. The PDA points to the Abandoned Lab entrance.
* Among Brothers: meet Stribog and Dazhbog at the Hospital. PDA markers
  guide you to the brothers, with a Hospital fallback before they spawn.
* Each brother's first meeting begins with his greeting, your introduction
  as sent by Chernobog, and his response. The meeting is counted after
  this exchange, rather than simply opening a conversation.
* Later visits use their regular greetings and streamlined menus.
* Includes the written dialogue and journal entries for both quests.


WORK AMONG BROTHERS
----------------------------------------------------------------------
Stribog
  "What can I do to serve our cause?" leads to his assignment conversation.
  His existing pool includes X-16 documents, Escort the Believer,
  Avenge the Sinners and Limansk Purge.

Dazhbog
  "Do the Masters have an assignment for me?" opens his storyline work:
  X-18 documents, Hunt the Forest Beast and Slay the Enemy Informer.
  "What tools do you need, brother?" retains the native toolkit dialogue
  for basic, advanced and expert deliveries.
  "Our Father said..." leads to his original Generators background.
  The original GAMMA mechanic tutorial remains available.

Assignments follow the original availability rules and selection system.
They are not a new fixed-order lab campaign. Completed lab jobs are not
reoffered; toolkit tiers unlock progressively. Existing turn-ins remain.
The custom assignment conversations guard against repeated acceptance.


HOSPITAL RESIDENTS
----------------------------------------------------------------------
Stribog, Dazhbog and the named guide have their squad destinations reinforced
as the Hospital while you are there. Their existing service-post logic now
ignores combat distractions, except when the player is hostile. They are not
made invulnerable. Missing or dead NPCs are not respawned, and no NPC is
teleported. Already displaced NPCs must return through native AI travel.
The supplied Re:Done service-NPC logic override must win its MO2 conflict.
Other squads, guards and NPCs are not changed.


DAZHBOG'S WORKBENCH
----------------------------------------------------------------------
* A permanent workbench stands behind Dazhbog in Re:Done's Hospital.
* Opens GAMMA's regular workshop and identifies Dazhbog as its owner.
* Toolkits handed in to him remain usable at this bench through his
  recorded toolkit tiers. Higher tiers also unlock the lower tiers.
* Uses normal crafting and repair requirements. It grants no duplicate
  toolkits, free materials or recipes, and adds no rental fee.
* Built from the installed GAMMA Hideout Furniture workbench assets.


THE HOSPITAL PASSAGE
----------------------------------------------------------------------
* Includes a local, two-way Sin climb through the broken Hospital opening.
* Harmless anomaly shimmers mark the route at the lower and upper heights;
  the upper effect sits directly above the lower one.
* Visual cues are Sin-only and appear when nearby. They are not damaging
  anomaly entities and add no radiation or hazard.
* Existing movement is retained, including the Use-key climb fallback.
  No level geometry or NPC navigation mesh is replaced.


INSTALLATION
----------------------------------------------------------------------
1. Close the game. Install this ZIP through Mod Organizer 2.
2. Name the installed mod RE:Sin. Put it below GAMMA/Re:Done and Press Key
   to Drop Item so RE:Sin wins its file conflicts.
3. Disable earlier Sin Cicatrix / RE:Sin versions and old Cicatrix fixes.
   Do not stack them. Full ZTC Core is not required; do not run its shield
   implementation alongside this one.
4. Keep the separate REVISION/Re:Done Cover Compatibility patch enabled
   if you are using the same setup that required it. That patch is separate
   from RE:Sin and is not bundled in this ZIP.
5. Launch through MO2.

Updating from Sin Cicatrix / RE:Sin 1.0.23:
  This version retains the difficulty-scaled shield balance. Your current save
  retains its shield charge, quest progress, meetings and workbench.
  No new game or save reset is needed. Internal script and save identifiers
  are deliberately retained for compatibility.

For the complete introduction, start as Sin or use a save before those
first meetings. Already recorded introductions will not play again.
English text is supplied, including English fallback in the Russian files.


SCOPE AND TESTING
----------------------------------------------------------------------
RE:Sin contains the Cicatrix and the Sin introduction described above.
It does not include ZTC's starting dog or unrelated ZTC gameplay features.
Original game and source-mod files were inspected read-only.

Checked outside the game: Lua syntax, dialogue links and script references,
installed DXML parsing, quest-state and marker behavior, duplicate-acceptance
checks, bench tool tiers and persistence, particle lifecycle, and local
Hospital placement checks against the installed collision data.

The author has tested development builds in game and supplied feedback.
The final package has not been independently game-tested by gpt, and not
every existing assignment has been verified through an in-game completion.


CREDITS
----------------------------------------------------------------------
romthevacuous
  Concept, creative direction, dialogue writing and revisions, balance
  decisions, in-game testing and feedback.

gpt
  Implementation assistance, integration, debugging, static checks,
  documentation and packaging.

SkyKi and the Zone Tweaks Collection contributors
  Original Cicatrix shield mechanics and particle / sound assets.
  SkyKi is credited in ZTC's included author metadata.
  Project: https://github.com/Skyki15/Ultimate-Zone-Tweaks

Grokitach and the GAMMA team / contributing addon authors
  GAMMA's gameplay framework, damage, crafting and repair systems.

eAkman and the Re:Done contributors
  Re:Done's northern-area and Hospital setup used by this integration.

Aoldri and the Hideout Furniture contributors
  Workbench model and furniture assets used from the installed GAMMA setup.

DoctorX, Tronex and the original Anomaly / S.T.A.L.K.E.R. contributors
  Existing quest, dialogue and workshop foundations.

All original assets and incorporated code remain credited to their
respective creators. This package makes no claim of ownership over them.

======================================================================
                               RE:Sin
                   May it preserve you in service to the Zone.
======================================================================
